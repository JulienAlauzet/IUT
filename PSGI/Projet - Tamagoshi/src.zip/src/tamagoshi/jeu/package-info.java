/**
 * Ce package permet de gérer une partie de Tamagoshis
 * 
 * @since Project 1.0
 * @author alauzetj
 * @version 1.0
 */

package tamagoshi.jeu;