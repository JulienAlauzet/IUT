/**
 * Ce package permet de gérer le comportement des Tamagoshis
 * 
 * @since Project 1.0
 * @author alauzetj
 * @version 1.0
 */

package tamagoshi.tamagoshis;