/**
 * Ce package permet de gérer les saisies utilisateur non-adéquates
 * 
 * @since Project 1.0
 * @author alauzetj
 * @version 1.0
 */

package tamagoshi.exceptions;