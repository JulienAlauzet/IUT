/**
 * Ce package contient tout ce qui se réfère au TP sur les Tamagoshis
 * 
 * @since Projetc 1.0
 * @author alauzetj
 * @version 1.0
 */

package tamagoshi;